/*
Author: Jayvin Duong

This script does the following:
- Creates the map with all the features listed in the GeoJSON file
- Handles AJAX request in order to write to the database
- Form Validation
============================================================================*/

// Declare global variables.
var map, layer, vectorLayers, features, featureControls, popup, coordinates, types;

// GeoJSON File name.
var geojsonFile = "generators.geojson";

// Restrict map boundaries.
var extent = new OpenLayers.Bounds(-98.20703, 39.28711, -70.88379, 56.77734);

// Map options.
var options = {
	restrictedExtent: extent,
	minScale: 15000000,
	numZoomLevels: 10,
	controls: [
		new OpenLayers.Control.Attribution(),
		new OpenLayers.Control.Navigation(),
		new OpenLayers.Control.PanZoomBar(),
		new OpenLayers.Control.KeyboardDefaults(),
		new OpenLayers.Control.MousePosition()
	]
};

/**
 * This function is used to initialize and create the map.
 */
function init() {
	
	// Change map width and height.
	$("#map").css("width","600px");
	$("#map").css("height","400px");
	
	// Create map object and set options.
	map = new OpenLayers.Map("map", options);
	
	layer = new OpenLayers.Layer.WMS(
		"OpenLayers WMS",
		"http://vmap0.tiles.osgeo.org/wms/vmap0",
		{layers: "basic"}
	);
	
	// Load the JSON file to plot the features on the map.
	OpenLayers.loadURL(geojsonFile, {}, null, onLoad, onLoadFailed);
	
	// Add baselayer to the map.
	map.addLayer(layer);
	
	// Zoom to the specfic location.
	map.zoomToMaxExtent();
	
}

/**
 * This function is used to handle a successful AJAX request to obtain the GeoJSON file.
 *
 * Params:
 * response - response handler
 */
function onLoad(response) {
	
	// If status is completed.
   	if (response.status == 200) {
		
		// Instantiate a GeoJSON object.
   		var geo = new OpenLayers.Format.GeoJSON();
		
		// Parse JSON file.
		var json = JSON.parse(response.responseText);
		
		// Create an array of vector layers based on how many features there are.
		vectorLayers = new Array(json.features.length);
		
		// Create arrays to store metadata.
		coordinates = new Array(json.features.length);
		types = new Array(json.features.length);
		
		// Loop and create the neccessary ammount of vector layers that are needed.
		for (var i = 0; i < json.features.length; i++) {
			
			// Create vector layer and add options.
			vectorLayers[i] = new OpenLayers.Layer.Vector(json.features[i].properties.name, {
				styleMap: setStyleMap(json.features[i].properties.type),
				isBaseLayer: false	
			});
			
			// Store parsed GeoJSON into arrays for easy accessiblity.
			vectorLayers[i][1] = json.features[i].properties.name;
			coordinates[i] = new Array(json.features[i].geometry.coordinates[0], json.features[i].geometry.coordinates[1]);
			types[i] = json.features[i].properties.type;
			
			// Deserialize a GeoJSON string and add the feature to the vector layer.
			var info = geo.read(json.features[i]);
			vectorLayers[i].addFeatures(info);
			
			// Add vector layer to the map.
			map.addLayer(vectorLayers[i]);
		}
		
		// Create a control feature for when the users select any feature.
		featureControls = new OpenLayers.Control.SelectFeature(vectorLayers);
		
		// Add the control feature to the map and activate it.
		map.addControl(featureControls);
		featureControls.activate();
		
		// Loop and create select feature event handlers.
		for (var i = 0; i < json.features.length; i++) {
			vectorLayers[i].events.on({
				'featureselected': onFeatureSelect,
				'featureunselected': onFeatureUnselect
			});	
		}
		
   	}
}

/**
 * This function is used to handle a failed AJAX request to obtain the GeoJSON file.
 *
 * Params:
 * response - response handler
 */
function onLoadFailed(response) {
	// If something goes wrong, write whatever code you want here.
}

/**
 * This function creates a cloud frame when the user selects a point on the map.
 *
 * Params:
 * evt - event handler
 */
function onFeatureSelect(evt) {

	var feature = evt.feature;
					
	// Grab the text from the JSON file and create text that will appear in the frame.
	var popupText = "<h2>"+ feature.attributes.name +"</h2>";
	popupText += "Location: "+ feature.attributes.location + "</br>";
	popupText += "Type: "+ feature.attributes.type + "</br>";
	popupText += "Capacity: "+ feature.attributes.capacity + " MW</br>";
	
	/* 
	 * Create a new frame.
	 * For constructor see:
	 * http://dev.openlayers.org/apidocs/files/OpenLayers/Popup-js.html#OpenLayers.Popup.OpenLayers.Popup
	 */
	popup = new OpenLayers.Popup.FramedCloud("featurePopup", feature.geometry.getBounds().getCenterLonLat(),
	new OpenLayers.Size(150,150), popupText, null, true, onPopupClose);
	
	feature.popup = popup;
	popup.feature = feature;
	
	// Closes all other popups first, then display the cloud frame.
	map.addPopup(popup, true);	
}

/**
 * This function hides a cloud frame when the user unselects a point on the map.
 *
 * Params:
 * evt - event handler
 */
function onFeatureUnselect(evt) {
	
	var feature = evt.feature;
	
	// Check to see if the pop is defined.
	if (feature.popup) {
		popup.feature = null;
		map.removePopup(feature.popup);
		feature.popup.destroy();
		feature.popup = null;
	}	
	
}

/**
 * This function handles the event when the user clicks the 'close' button on the cloud frame.
 *
 * Params:
 * evt - event handler
 */
function onPopupClose(evt) {
	
	// 'this' is the popup.
	var feature = this.feature;
							
	// The feature is not destroyed
	if (feature.layer) { 
		featureControls.unselect(feature);
	} 
							
	// After "moveend" or "refresh" events on POIs layer all.
	else { 
		// Features have been destroyed by the Strategy.BBOX.
		this.destroy();
	}
}

/**
 * This function toggles user specfic points on/off.
 *
 * Params:
 * pointID - the ID of which point to hide
 */
function togglePoint(pointID) {
	
	// Loop through the vectorLayers array in order to determine which layer needs to be toggled.
	for (var i = 0; i < vectorLayers.length; i++) {
		
		// Determine layer and set visibility.
		if (pointID == vectorLayers[i][1]) {
			vectorLayers[i].getVisibility() ? vectorLayers[i].setVisibility(false) : vectorLayers[i].setVisibility(true);
		}
		
	}
	
}

/**
 * This function determine whether layer with the same type of generator should be hidden or display.
 *
 * Params:
 * type - which generator type to toggle on/off
 */
function toggleLayerTypes(type) {
	
	// Determine if rows containing the same type need to be hidden or displayed, then update the table.
	if ($("."+ type).is(":visible")) {
		$("."+ type).fadeOut("slow", function() {
			$(this).css("background","none");
			redrawTable();
		});
	}
	
	else {
		$("."+ type).fadeIn("slow", function() {redrawTable();} );
	}
	
	// Force any checkboxes to be checked to solve user-experience issues.
	$("."+ type +" input:checkbox").attr("checked", "checked");
	
	// Determine whether to hide or show layers.
	$("#"+type).is(":checked") ? toggleType(true, type) : toggleType(false, type);
	
}

/**
 * This function will fix the table's alternating row colors.
 */
function redrawTable() {
	
	// Variable used to alternate colors.
	var i = 0;
	
	// For each row visible in the table, change the background.
	$("#gen_table tr:visible").each(function() {
		i % 2 == 0 ? $(this).css("background","#FFF") : $(this).css("background","#DDD");
		i++;
	});	
	
}

/**
 * This function hides or displays layers with the same type.
 *
 * Params:
 * shouldDisplay - if the layers need to be shown or hidden
 * type - which generator type to toggle on/off
 */
function toggleType(shouldDisplay, type) {
	// Loop through the vectorLayers array in order to determine which layer needs to be toggled.
	for (var i = 0; i < vectorLayers.length; i++) {
		
		// Determine type and set layer visibility.
		if (type == types[i]) {
			vectorLayers[i].setVisibility(shouldDisplay);
		}
		
	}	
}

/**
 * This function creates a style map that will apply to different types of generators.
 *
 * Params:
 * type - the generator type as a string
 * Returns:
 * style - a style map object
 */
function setStyleMap(type) {
	
	// Declare string which will include the path to the img directory.
	var graphic = "img/";
	
	// Make each generator type have a different graphic image.
	switch (type) {
		case "Nuclear":
			graphic += "nuclear_icon.png";
			break;
		case "Wind":
			graphic += "wind_icon.png";
			break;
		case "Solar":
			graphic += "solar_icon.png";
			break ;
		case "Hydro":
			graphic += "hydro_icon.png";
			break;
		case "Coal":
			graphic += "coal_icon.png";
			break;
		case "Bio-Energy":
			graphic += "bio_energy_icon.png";
			break;
		case "Bio-Mass":
			graphic += "bio_mass_icon.png";
			break;	
		case "Gas":
			graphic += "gas_icon.png";
			break;
		default:
			graphic += "marker.png";
	}
	
	// Create a StyleMap object.
	style = new OpenLayers.StyleMap({
		"default": {
			externalGraphic: graphic,
			pointRadius: 13,
			fillOpacity: 1
		},
		"select": {
			pointRadius: 12,
			fillOpacity: 0.8
		}
	});
	
	return style;
}

/**
 * AJAX Request Handling
 * ==========================================================================================
 */
 
/**
 * This function handles the post AJAX request.
 */ 
function handleRequest() {
	
	// Declare new XHR.
	var http = new XMLHttpRequest();
	var params;

	// Append params with the valid form values.
	params = "form_gen_name="+ $("#gen_name").val();
	params += "&form_gen_type="+ $("#gen_type").val();
	params += "&form_gen_capacity="+ $("#gen_cap").val();
	params += "&form_gen_location="+ $("#gen_loc").val();
	params += "&form_gen_lat="+ $("#gen_lat").val();
	params += "&form_gen_long="+ $("#gen_lng").val();
	
	// Handle POST request.
	http.open("POST", "write_db.php", true);
	
	//Send the proper header information along with the request
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	http.setRequestHeader("Content-length", params.length);
	http.setRequestHeader("Connection", "close");
	
	//Call a function when the state changes.
	http.onreadystatechange = function() {
		
		// Page is complete and done loading, then refresh the page.
		if(http.readyState == 4 && http.status == 200) {
			window.location.reload(true);
		}
		
	}
	
	// Send params in order for the php script.
	http.send(params);
	
}

/**
 * Form Validation Code
 * ==========================================================================================
 */

// Declare global variables.
var isErrorBoxPopulated = false;
var minCoor = -100;
var maxCoor = 100;

/**
 * This function validates the new generator form.
 */
function validate() {
	
	// String for error messages.
	var msg = "";
	
	// Empty generator name.
	if ($("#gen_name").val().length == 0) {
		msg += "<p>Empty generator name</p>";
	}
	
	// Empty location name.
	if ($("#gen_loc").val().length == 0) {
		msg += "<p>Empty location name</p>";
	}
	
	// Empty capacity name.
	if ($("#gen_cap").val().length == 0) {
		msg += "<p>Empty capacity value</p>";
	}
	
	else {
		// Capacity needs to be a number.
		if (isNaN($("#gen_cap").val())) {
			msg += "<p>Capacity value needs to be a number</p>";
		}
	}
	
	// Empty latitude name.
	if ($("#gen_lat").val().length == 0) {
		msg += "<p>Empty latitude value</p>";
	}
	
	// Empty longitude name.
	if ($("#gen_lng").val().length == 0) {
		msg += "<p>Empty longitude value</p>";
	}
	
	// Valid cooridnates.
	if (areCoordinatesInvalid($("#gen_lng").val()) || areCoordinatesInvalid($("#gen_lat").val()) ) {
		msg += "<p>Invalid latitude/longitude cooridnates</p>";
	}
	
	// Prevent possible duplicate records before writing into the database.
	if (doesGeneratorExist()) {
		msg += "<p>That generator exists already</p>";
	}
	
	// Determine if there has been any errors, if not write to the database.
	if (msg.length == 0) {
		handleRequest();
	}
	
	// Print out errors.
	else {
		$("#form_errors").html(msg);
	
		// Switch boolean to true in order to clear the error console.
		isErrorBoxPopulated = true;	
	}
	
}

/**
 * This function checks to see if the generator name exist in the database to prevent having duplicate records.
 *
 * Returns:
 * a boolean if a similar generataor exist
 */
function doesGeneratorExist() {
	
	// Store form values into instance variables.
	var gen_lat = $("#gen_lat").val();
	var gen_lng = $("#gen_lng").val();

	for (var i = 0; i < coordinates.length; i++) {
		if (coordinates[i][0] == gen_lng && coordinates[i][1] == gen_lat) {
			return true;
		}	
	}
	
	return false;
}
 
/**
 * This function checks to see if the form value from an input text box is a number.
 *
 * Params:
 * field - which form field that needs validating
 * formValue - the value that was used to fill in field
 */
function checkNaN(field, formValue) {
	
	// Clear error console.
	clearErrorConsole();
	
	// NaN = Not a Number
	if (isNaN(formValue)) {
		// Check to see to determine that 2 of the same errors messages dont display.
		if (!$("#nan_"+ field).length) {
			$("#form_errors").append("<div id='nan_"+field+"'>" +field+ ":  needs to be a NUMBER.</div>");
		}
	}
	
	// Form value is a number.
	else {
		// Remove error message.
		$("#nan_"+field).remove();
		
		// Determine if the cooridnates are valid.
		if (field == "Longitude" || field == "Latitude") {
			isCoordinateOutOfBounds(field, formValue);
		}
	}
	
}

/**
 * This function checks to see if the long/lat values are out of bounds.
 *
 * Params:
 * field - which form field that needs validating
 * value - the value that was used to fill in field
 */
function isCoordinateOutOfBounds(field, value) {
	
	// Restricted range of values that are NOT valid.
	if (value < minCoor || value > maxCoor) {
		// Check to see to determine that 2 of the same errors messages dont display.
		if (!$(".bounds"+ field).length) {
			$("#form_errors").append("<div id='bounds_"+field+"'>" +field+ ":  is out of bounds.</div>");
		}
	}
	
	// Form value in range.
	else {
		// Remove error message.
		$("#bounds_"+field).remove();
	}
	
}


/**
 * This overloaded function checks to see if the long/lat values are out of bounds.
 *
 * Params:
 * value - the value that was used to fill in field
 * Returns
 * A boolean if the coordinates are out of bounds
 */
function areCoordinatesInvalid(value) {
	
	// Restricted range of values that are NOT valid.
	if (value < minCoor || value > maxCoor) {
		return true;
	}
	
	// Form value in range.
	else {
		return false;
	}
	
}

/**
 * This function clears out the error box.
 */
function clearErrorConsole() {
	
	// Check to see if the error box is populated.
	if (isErrorBoxPopulated) {
		
		// Clear console.
		$("#form_errors").html("");
		
		// Reset value.
		isErrorBoxPopulated = false;
	}
	
}