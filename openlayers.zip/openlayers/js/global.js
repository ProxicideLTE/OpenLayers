// Canada data layer.
var dm_wms = new OpenLayers.Layer.WMS(
	"Canadian Data",
	"http://www2.dmsolutions.ca/cgi-bin/mswms_gmap",
	{
		layers: "bathymetry,land_fn,park,drain_fn,drainage," + "prov_bound,fedlimit,rail,road,popplace",
		transparent: "true",
		format: "image/png"
	},
	{isBaseLayer: false, visibility: false}
);

// Array of x and y coordinates for the features that will displayed on the map. 
var xCoords = [-79.35, -79.39, -79.51, -79.20, -79.50, -79.25, -79.32, -79.35, -79.44];
var yCoords = [43.65, 43.60, 43.60, 43.73, 43.72, 43.59, 43.71, 43.57, 43.70];

var map;

// Style map for the features.
var styles = new OpenLayers.StyleMap({
	"default": {
			graphicName: "${type}",
			pointRadius: 7,
			strokeColor: "black",
			strokeWidth: 1,
			fillColor: "white",
			fillOpacity: 0.8
    	}
    });

// Create vector layers and give it your style map.
var circleLayer = new OpenLayers.Layer.Vector("Circles Features", {
	styleMap: styles,
	isBaseLayer: false,
	visibility: true
});
	
var squareLayer = new OpenLayers.Layer.Vector("Square Features", {
	styleMap: styles,
	isBaseLayer: false,
	visibility: true
});

var circleFeatures = new Array(xCoords.length);
var squareFeatures = new Array(xCoords.length);

/*
 * This function will generate the map and all the layers associated with it.
 */
function display() {
	
	// Restrict the map to a specfic location.
	var extent = new OpenLayers.Bounds(-79.88022, 43.40836, -78.47672, 44.02359);
	
	// Map options.
	var options = {
		restrictedExtent: extent,
		minScale: 650000,
			controls: [
			new OpenLayers.Control.PanZoomBar()
			]
	};
	
	// Map object.
	map = new OpenLayers.Map("map", options);
	
	// Layer objects.
	var ol_wms = new OpenLayers.Layer.WMS(
		"OpenLayers WMS",
		"http://vmap0.tiles.osgeo.org/wms/vmap0",
		{layers: "basic"}
	);
	
	// Create features.
	for (var i = 0; i < xCoords.length; i++) {
		
		// Create circle features with the according cooridinates.
		circleFeatures[i] = new OpenLayers.Feature.Vector(new OpenLayers.Geometry.Point(xCoords[i], yCoords[i]), {
            type: "circle"
        });
		
		// Create square features with the according cooridinates.
		squareFeatures[i] = new OpenLayers.Feature.Vector(new OpenLayers.Geometry.Point(0.45+xCoords[i], 0.15+yCoords[i]), {
            type: "square"
        });
		
	}
	
	// Add features to the vector layer.
	circleLayer.addFeatures(circleFeatures);
	squareLayer.addFeatures(squareFeatures);

	// Add layers to the map.
	map.addLayers([ol_wms, dm_wms, circleLayer, squareLayer]);
	// map.addControl(new OpenLayers.Control.LayerSwitcher());  // Display layer control menu
	
	// Zoom in to the location.
	map.zoomToExtent(extent);
	
	// Display layer when user clicks on the checkbox.
	$("#toggle_canada_data").click(function() {
			
			// Show Canada data.
			if (!dm_wms.getVisibility()) {
				dm_wms.setVisibility(true);
				$("#toggle-canada").html("Hide");
				$("#canada-options").slideToggle();
			}
			
			// Hide Canada data.
			else {
				dm_wms.setVisibility(false);
				$("#toggle-canada").html("Show");
				$("#canada-options").slideToggle();
			}
		}
	);
	
	// Display/hide circles when user clicks on the checkbox.
	$("#toggle_circles").click(function() {
			
			// Show circles.
			if (!circleLayer.getVisibility()) {
				circleLayer.setVisibility(true);
			}
			
			// Hide circles.
			else {
				circleLayer.setVisibility(false);
			}
		}
	);
	
	// Display/hide squares when user clicks on the checkbox.
	$("#toggle_squares").click(function() {
			
			// Show squares.
			if (!squareLayer.getVisibility()) {
				squareLayer.setVisibility(true);
			}
			
			// Hide squares.
			else {
				squareLayer.setVisibility(false);
			}
		}
	)
	
}

/*
 * This function will display or hide the specfic layer.
 * Parameters:
 * type - the type of feature that will have its color changed
 */
function setLayerVisiblity(layerType) {
	
}


/*
 * This function will change the specfic features with the specfic color the user has selected.
 * Parameters:
 * type - the type of feature that will have its color changed
 * color - the new color that needs to be changed 
 */
function changeColor(type, color) {
	// alert("Change "+ type +" with the color "+ color);
	
	// Redraw circles with a different color.
	if (type == "circles") {
		for (var i=0; i < xCoords.length; i++) {
			circleLayer.drawFeature(circleFeatures[i], {
					pointRadius: 7,
					strokeColor: "black",
					strokeWidth: 1,
					fillColor: color,
					fillOpacity: 1
				});
		}
	}
	
	// Redraw squares with a different color.
	else {
		for (var i=0; i < xCoords.length; i++) {
			squareLayer.drawFeature(squareFeatures[i], {
					graphicName: "square",
					pointRadius: 7,
					strokeColor: "black",
					strokeWidth: 1,
					fillColor: color,
					fillOpacity: 1
				});
		}
	}
}


/*
 * This function will display more options depending on what the user has selected.
 * Parameters:
 * ID - which ID to display/hide
 */
function displayMoreOptions(id) {
	
	// Reset buttons if any are present.
	$("#"+ id +" input:radio").attr("checked", false);
	
	$("#"+id).slideToggle("slow");
	
}