<?php 

$connection = mysql_connect("localhost", "duongja", "991165542");

$db = mysql_select_db("duongja",$connection) or die ("could not select db");

/*
 * This section of the script writes to the database.
 * ================================================================================
 */

// Store form values into variables for easy access.
$name = $_POST["form_gen_name"];
$type = $_POST["form_gen_type"];
$cap = $_POST["form_gen_capacity"];
$loc = $_POST["form_gen_location"];
$lat = $_POST["form_gen_lat"];
$long = $_POST["form_gen_long"];

// Create SQL query to insert new generators into the database.
$insert_query = "
INSERT INTO generators (genname, gentype, gencapacity, genlocation, lat, lng)
VALUES('". $name ."', '". $type ."', ". $cap .", '".$loc ."', '". $lat ."', '". $long ."')";

// Pass the query to the databsae.
mysql_query($insert_query) or die ("Could not write into the database.");


?>