<?php

echo "This script is used to clear the Generators table completly";

// Include db_connect.php to get a connection to the database.
include("../../includes/db_connect.php");

/*
 * Clear the database.
 */

$delete_query = '
DELETE FROM generators
';

// Pass the query to the databsae.
mysql_query($delete_query) or die ("Error while deleting to the database.");

/*
 * Clear the file.
 */
 
// File to work with.
$fileName = "generators.geojson";

// Create a file handler to write to the file.
$fileWriteHandler = fopen($fileName, 'w') or die("Couldn't open the file");

// If the file was opened properly. then write to the file.
fwrite($fileWriteHandler, "") or die("Couldn't write to the file");

// Close file handler.
fclose($fileWriteHandler);

?>