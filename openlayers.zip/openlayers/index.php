<?php
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<meta http-equiv="expires" content="FRI, 13 APR 1999 01:00:00 GMT">
<META name="ROBOTS" content="NOINDEX, NOFOLLOW, NOARCHIVE">

<title>Generators - OpenLayers</title>

<link rel="stylesheet" href="style.css" type="text/css">	<!-- CSS reset file -->

<script type="text/javascript" src="js/OpenLayers.js"></script>
<script type="text/javascript" src="js/tooltip.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>

<?php

$connection = mysql_connect("localhost", "duongja", "991165542");

$db = mysql_select_db("duongja",$connection) or die ("could not select db");

// Instanitate varibales.
$htmlTable = createHTMLString();

// Update file.
rewriteFile(createGeoJSONString());

/*
 * This function rewrites the GeoJSON file so that that it is constantly updated.
 *
 * Params:
 * geojson - a string that will contain the text that will appear in the file
 */
function rewriteFile($geojson) {
	// File to work with.
	$fileName = "generators.geojson";
	
	// Create a file handler to write to the file.
	$fileWriteHandler = fopen($fileName, 'w') or die("Couldn't open the file");
	
	// If the file was opened properly. then write to the file.
	fwrite($fileWriteHandler, $geojson) or die("Couldn't write to the file");
	
	// Close file handler.
	fclose($fileWriteHandler);
}

/*
 * This function creates proper GeoJSON syntax that is nessecary for the file.
 *
 * Returns:
 * $geojson - a string that hold GeoJSON content
 */
function createGeoJSONString() {
	
	// Get information and store it into an instance variable.
	$results = getGeneratorData();
	
	// Initialize geojson string.
	$geojson = '
	{
		"type": "FeatureCollection",	
		"features":[
	';
	$i = 1;
	
	// Loop records and append to the table.
	while($row_name = mysql_fetch_array($results)) {
		
		// Assign record values to local variables.
		$genName = $row_name['genname'];
		$genType = $row_name['gentype'];
		$genCap = $row_name['gencapacity'];
		$genLoc = $row_name['genlocation'];
		$genLat = $row_name['lat'];
		$genLong = $row_name['lng'];
		
		// Append GeoJSON string.
		$geojson .= 
		'
			{ "type": "Feature", "geometry": {"type": "Point", "coordinates": ['. $genLong .', '. $genLat .'] },
			  "properties": {
				  "name": "'. $genName .'",
				  "type": "'. $genType .'",
				  "capacity": '. $genCap .',
				  "location": "'. $genLoc .'"
			  }
		';
		
		// Determine if there are more generators or not to create the proper syntax.
		$geojson .= ($i == getNumberOfGenerators()) ? "}" : "},";
		
		$i++;
	}
	
	// Append to properly close the GeoJSON file.
	$geojson .= '
	  ]
	}
	';
	
	return $geojson;
}

/*
 * This function creates a HTML string then returns it.
 *
 * Returns:
 * $htmlTable - a HTML table 
 */
function createHTMLString() {
	
	// Get information and store it into an instance variable.
	$results = getGeneratorData();
	$i = 0; // used to alternate row colors.
	
	// Create inital table.
	$htmlTable = "<table width='100%' id='gen_table'>
	<tr id='table-heading'>
		<td><b>Toggle</b></td>
		<td><b>Name</b></td> 
		<td><b>Type</b></td> 
		<td><b>Capacity</b></td> 
		<td><b>Location</b></td> 
		<td><b>Longitude</b></td>
		<td><b>Latitude</b></td> 
	</tr>
	";
	
	// Loop records and append to the table.
	while($row_name = mysql_fetch_array($results)) {
		
		// Assign record values to local variables.
		$genID = $row_name['genid'];
		$genName = $row_name['genname'];
		$genType = $row_name['gentype'];
		$genCap = $row_name['gencapacity'];
		$genLoc = $row_name['genlocation'];
		$genLat = $row_name['lat'];
		$genLong = $row_name['lng'];
		
		// Alternate row colors.
		$htmlTable .= (($i % 2) == 1) ? "<tr class=\"". $genType ."\">" : "<tr class=\"". $genType ."\" bgcolor='#DDD'>";
		
		// Append output from the query to the html table.
		$htmlTable .= "<td><input id=\"". $genID ."_toggle\" type='checkbox' onclick='togglePoint(\"". $genName ."\");' checked /></td>";
		$htmlTable .= "<td><label for=\"". $genID ."_toggle\" >". $genName ."</label></td>";
		$htmlTable .= "<td>". $genType ."</td>";
		$htmlTable .= "<td>". $genCap ." MW</td>";
		$htmlTable .= "<td align='center'>". $genLoc ."</td>";
		$htmlTable .= "<td>". $genLong ."</td>";
		$htmlTable .= "<td>". $genLat ."</td>";
		$htmlTable .= "</tr>";
		
		$i++;
	}

	// Close table tag.
	$htmlTable .= "</table>";
	
	return $htmlTable;
	
}

/*
 * This function will return an array with all the generators metadata.
 *
 * Returns:
 * results - an array with all the records 
 */
function getGeneratorData() {
	// Create SQL query.
	$query_name = "SELECT * FROM generators";
	
	// Pass query.
	$results = mysql_query($query_name) or die ("$query_name did not work"); 
	
	return $results;
}

/*
 * This function will return the total number of generators are that found in the database.
 *
 * Returns:
 * total - total number of generators 
 */
function getNumberOfGenerators() {
	
	$total;
	
	 // Create query to count how many generators exist in the database.
	$count_query = "SELECT COUNT(*) as TotalGen FROM generators";
	
	// Pass query.
	$count_results = mysql_query($count_query) or die ("$count_query did not work"); 
	
	// Fetch result and store value into an instance variable.
	while($row_name = mysql_fetch_array($count_results)) {
		$total = $row_name['TotalGen'];
	}
	
	return $total;
}

?>

</head>

<body onload="init();">
<h1>Generators</h1>

<div style="width: 100%;">

<div style="float: left;">

	<div id="map" class="smallmap"></div>
    
    <div id="toggle_types">
    	<hr />
    	<p>
    		<label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Nuclear')" id="Nuclear"/> Nuclear</label>
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Gas')" id="Gas"/> Gas</label>
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Wind')" id="Wind"/> Wind</label>
            
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Solar')" id="Solar"/> Solar</label>
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Hydro')" id="Hydro"/> Hydro</label>
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Coal')" id="Coal" /> Coal</label>
            
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Bio-Energy')" id="Bio-Energy"/> Bio-Energy</label>
            <label><input type="checkbox" checked="checked" onclick="toggleLayerTypes('Bio-Mass')" id="Bio-Mass"/> Bio-Mass</label>
       	</p>
    </div>
    
</div>

<div style="float: right; width="600">
<h2>Insert a New Generator</h2>

    <form>
        <table width="600">
            <tr>
                <td><label for="gen_name">Name:</label></td>
                <td><input id="gen_name" type="text" name="form_gen_name" size="25" /></td>
            </tr>
            <tr>
                <td><label for="gen_loc">Location:</label></td>
                <td><input id="gen_loc" type="text" name="form_gen_loc" size="15" /></td>
            </tr>
            
            <tr>
                <td colspan="2">Generator Details</td>
            </tr>
            
            <tr>
                <td><label for="gen_type">Type:</label></td>
                <td>
                    <select id="gen_type" name="form_gen_type">
                        <option value="Nuclear">Nuclear</option>
                        <option value="Gas">Gas</option>
                        <option value="Wind">Wind</option>
                        <option value="Solar">Solar</option>
                        <option value="Hydro">Hydro</option>
                        <option value="Coal">Coal</option>
                        <option value="Bio-Energy">Bio-Energy</option>
                        <option value="Bio-Mass">Bio-Mass</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="gen_cap">Capacity (MW):</label></td>
                <td><input id="gen_cap" type="text" name="form_gen_capacity" maxlength="5" size="4" onchange="checkNaN('Capacity',this.value);" /></td>
            </tr>
            
            <tr>
                <td colspan="2">Generator Cooridnates</td>
            </tr>
            
            <tr>
                <td><label for="gen_lng">Longitude:</label></td>
                <td><input id="gen_lng" type="text" name="form_gen_long" maxlength="11" size="9" onchange="checkNaN('Longitude',this.value);" /></td>
            </tr>
            
            <tr>
                <td><label for="gen_lat">Latitude:</label></td>
                <td><input id="gen_lat" type="text" name="form_gen_lat" maxlength="11" size="9" onchange="checkNaN('Latitude',this.value);" /></td>
            </tr>
            <tr>
                <td colspan="2">
                    <input id="submit" type="button" value="Submit" onclick="validate();" />
                </td>
            </tr>
        </table>
    </form>

	<div id="form_errors" style="color: #F00; font-weight: bold;"></div>
</div>

</div>

<div style="clear: both;">

<h1>List of Generators</h1>
<?php echo $htmlTable ."<p> Total: ". getNumberOfGenerators() ." generators</p>"; ?>

</div>

</body>

</html>